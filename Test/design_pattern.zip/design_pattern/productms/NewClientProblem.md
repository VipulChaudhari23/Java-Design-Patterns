Our application has an OldClient which is using IOldProductService contract,
Our application is currently successfully supporting this client, 

We want to support a new client who is using different Service contract INewProductService which our application is not currently supporting,

Please provide the solution to support new client, The support to old client should not get disturbed  
Please see the code for the problem in productproblem package
