package com.maveric.loggerproblem;

public interface ILogger {
void info(String msg);
void error(String msg);
}
