An inhouse Logger library implementation exists which is getting used for the application, 

Currently messages are not logged with date and time, 

Enhance logger functionality without changing the existing logging library implementation so that the logged messages are preceeded by the date and time of the logged messages

Please see source of problem in loggerproblem package


